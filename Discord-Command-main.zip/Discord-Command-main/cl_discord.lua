RegisterCommand('discordserver', function()
    TriggerEvent('chat:addMessage', {                                                                                                                               -- EDIT ME! 🡫🡫🡫🡫🡫🡫
        template = '<div style="padding: 0.5vw; margin: 0.5vw; background-color: rgba(16, 18, 33, 1.0); border-radius: 3px;"><i class="fab fa-discord"></i> {0}:<br> Discord.gg/DiscordServer </div>',
        args = {' Join Our Discord!'}      -- If you like transparent, change me from 1.0 to 0.6! 🡩🡩
    })
end)





░█████╗░░█████╗░██████╗░░██████╗░░░██████╗░███████╗██╗░░░██╗
██╔══██╗██╔══██╗██╔══██╗██╔════╝░░░██╔══██╗██╔════╝██║░░░██║
██║░░╚═╝███████║██████╔╝╚█████╗░░░░██║░░██║█████╗░░╚██╗░██╔╝
██║░░██╗██╔══██║██╔═══╝░░╚═══██╗░░░██║░░██║██╔══╝░░░╚████╔╝░
╚█████╔╝██║░░██║██║░░░░░██████╔╝██╗██████╔╝███████╗░░╚██╔╝░░
░╚════╝░╚═╝░░╚═╝╚═╝░░░░░╚═════╝░╚═╝╚═════╝░╚══════╝░░░╚═╝░░░