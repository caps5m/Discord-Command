# Discord-Command

a cool command to add to your FiveM servers! this LUA Code registers a command which can be used by your players (/discord or /discordserver) to help spread your discord server to all of your in game players to help grow your roleplay communities!
